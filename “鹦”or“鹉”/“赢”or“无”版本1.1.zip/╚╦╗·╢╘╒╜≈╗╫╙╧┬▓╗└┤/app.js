// app.js
App({
  globalData: {
    game_num:10,//总局数
    game_money:1000,//筹码数
    userInfo:"",
  },
})
