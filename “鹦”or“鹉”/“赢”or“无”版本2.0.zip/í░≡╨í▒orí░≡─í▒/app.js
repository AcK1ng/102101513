// app.js
App({
  globalData: {
    game_num:5,//总局数
    game_money:1000,//筹码数
    userInfo:"",
  },
})
