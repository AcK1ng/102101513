// pages/createroom/createroom.js
const app = getApp()
var num;
var money;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo:{},
    RoomName:"",
    RoomPsw:"",
    game_num:10,
    game_money:1000
  },
  createRoom(){
    wx.showToast({
      title: '敬请期待！',
      icon:'none',
      duration:2000
    })

  },
  jump2(){
    wx.redirectTo({
      url: '/pages/home/home',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      userInfo:app.globalData.userInfo
    });
    num=app.globalData.game_num;
    money=app.globalData.game_money;
    this.setData({game_num:num});
    this.setData({game_money:money});
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {
    wx.closeSocket({
      code: 4000,
    });
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    wx.closeSocket({
      code: 4000,
    });
  },

  setRoomName:function(e){
    this.setData({
      RoomName:e.detail.value 
    });
  },

  setRoomPsw:function(e){
    this.setData({
      RoomPsw:e.detail.value
    });
  },
  add_times: function () {
    if(num>=5&&num<100){
      num=num+5;
      this.setData({game_num:num});
    }
    app.globalData.game_num=num;
  },
  sub_times: function () {
  
    if(num<=100&&num>5){
      num=num-5;
      this.setData({game_num:num});
    }
    app.globalData.game_num=num;
  },
  add_money: function () {
    
    if(money>=500&&money<10000){
      money=money+250;
      this.setData({game_money:money});
    }
    app.globalData.game_money=money;
  },
  sub_money: function () {
    if(money>500&&money<=10000){
      money=money-250;
      this.setData({game_money:money});
    }
    app.globalData.game_money=money;
  }
})